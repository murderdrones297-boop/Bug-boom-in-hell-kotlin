package com.bigboominhell.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.*
import kotlin.random.Random

/** Native Kotlin ray-cast prototype. No WebView or JavaScript runtime is used. */
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var loop: Thread? = null
    @Volatile private var running = false
    private val map = arrayOf(
        "1111111111111111", "1000000000000001", "1020000000003001", "1000110001100001",
        "1000100000100001", "1000000000000001", "1000003000000001", "1000110000110001",
        "1000000000000001", "1000000000000001", "1000000000000001", "1111111111111111"
    )
    private var px = 2.5f; private var py = 2.5f; private var angle = 0f
    private var hp = 100; private var ammo = 40; private var kills = 0
    private var shotFlash = 0f; private var hurtFlash = 0f
    private data class Enemy(var x: Float, var y: Float, var hp: Int = 2, var cooldown: Float = 0f)
    private val enemies = mutableListOf(Enemy(8.5f, 2.5f), Enemy(12.5f, 7.5f), Enemy(5.5f, 9.5f), Enemy(13.2f, 4.5f))
    private var move = 0f; private var turn = 0f; private var firing = false
    private var last = System.nanoTime()

    init { holder.addCallback(this); isFocusable = true }
    override fun surfaceCreated(holder: SurfaceHolder) { running = true; loop = Thread(this, "BBI-GameLoop").also { it.start() } }
    override fun surfaceDestroyed(holder: SurfaceHolder) { running = false; loop?.join(500); loop = null }
    override fun run() {
        while (running) {
            val now = System.nanoTime(); val dt = ((now - last) / 1e9).toFloat().coerceIn(0f, .05f); last = now
            update(dt)
            if (holder.surface.isValid) { val c = holder.lockCanvas(); if (c != null) { drawGame(c); holder.unlockCanvasAndPost(c) } }
            try { Thread.sleep(12) } catch (_: InterruptedException) { }
        }
    }
    private fun solid(x: Float, y: Float): Boolean {
        val ix=x.toInt(); val iy=y.toInt(); return iy !in map.indices || ix !in map[0].indices || map[iy][ix] != '0'
    }
    private fun update(dt: Float) {
        angle = (angle + turn * dt * 2.2f + Math.PI.toFloat()*2) % (Math.PI.toFloat()*2)
        val nx=px+cos(angle)*move*dt*3f; val ny=py+sin(angle)*move*dt*3f
        if (!solid(nx,py)) px=nx; if (!solid(px,ny)) py=ny
        shotFlash=(shotFlash-dt*4).coerceAtLeast(0f); hurtFlash=(hurtFlash-dt*1.8f).coerceAtLeast(0f)
        enemies.forEach { e ->
            val dx=px-e.x; val dy=py-e.y; val d=hypot(dx,dy)
            if (d>1.1f && d<8f) { val ex=e.x+dx/d*dt*.42f; val ey=e.y+dy/d*dt*.42f; if(!solid(ex,e.y)) e.x=ex; if(!solid(e.x,ey)) e.y=ey }
            e.cooldown-=dt
            if(d<1.15f && e.cooldown<=0f) { hp=(hp-5).coerceAtLeast(0); hurtFlash=1f; e.cooldown=1.1f }
        }
        if (firing && ammo>0 && shotFlash<=0f) shoot()
    }
    private fun shoot() {
        ammo--; shotFlash=1f
        val target=enemies.filter { e ->
            val dx=e.x-px; val dy=e.y-py; val dist=hypot(dx,dy); val a=atan2(dy,dx); val diff=abs(((a-angle+Math.PI*3)%(Math.PI*2))-Math.PI)
            diff<.12f && dist<9f && clearShot(dist,a)
        }.minByOrNull { hypot(it.x-px,it.y-py) }
        if(target!=null) { target.hp--; if(target.hp<=0) { enemies.remove(target); kills++ } }
    }
    private fun clearShot(dist: Float, a: Float): Boolean { var d=.2f; while(d<dist) { if(solid(px+cos(a)*d,py+sin(a)*d)) return false; d+=.12f }; return true }
    private fun drawGame(c: Canvas) {
        val w=c.width.toFloat(); val h=c.height.toFloat(); c.drawColor(Color.rgb(12,8,9))
        p.style=Paint.Style.FILL
        p.color=Color.rgb(35,15,18); c.drawRect(0f,0f,w,h*.48f,p)
        p.color=Color.rgb(40,27,24); c.drawRect(0f,h*.48f,w,h,p)
        // perspective floor seams and molten fissures
        for(i in 1..9) { val y=h*.48f+(h*.52f)*(i/10f).pow(1.7f); p.color=if(i%3==0) Color.rgb(160,55,22) else Color.rgb(75,48,39); p.strokeWidth=if(i%3==0) 2f else 1f; c.drawLine(0f,y,w,y,p) }
        val zbuf=FloatArray(w.toInt().coerceAtLeast(1)) { 99f }
        val rays=w.toInt().coerceAtLeast(1)
        for(x in 0 until rays) {
            val ra=angle+(x.toFloat()/w-.5f)*1.15f; var d=.04f; var hit='1'
            while(d<18f) { val tx=px+cos(ra)*d; val ty=py+sin(ra)*d; if(solid(tx,ty)) { val ix=tx.toInt().coerceIn(0,map[0].lastIndex); val iy=ty.toInt().coerceIn(0,map.lastIndex); hit=map[iy][ix]; break }; d+=.035f }
            val corrected=(d*cos(ra-angle)).coerceAtLeast(.05f); zbuf[x]=corrected
            val wallH=(h*.82f/corrected).coerceAtMost(h*1.5f); val top=h*.48f-wallH/2
            val shade=(210f/(1f+corrected*.22f)).toInt().coerceIn(25,190); val base=if(hit=='2') Color.rgb(shade,35,20) else if(hit=='3') Color.rgb(60,shade/2,shade/2) else Color.rgb(shade,shade*3/5,shade*2/5)
            p.color=base; c.drawRect(x.toFloat(),top,x+1f,top+wallH,p)
            if(x%12==0) { p.color=Color.argb(45,255,100,25); c.drawLine(x.toFloat(),top,x.toFloat(),top+wallH,p) }
        }
        // billboard enemies, depth-tested against walls
        enemies.sortedByDescending { hypot(it.x-px,it.y-py) }.forEach { e ->
            val dx=e.x-px; val dy=e.y-py; val dist=hypot(dx,dy); val da=atan2(dy,dx); val diff=((da-angle+Math.PI*3)%(Math.PI*2))-Math.PI
            if(abs(diff)<.65f && dist>.1f) {
                val sx=(.5f+diff/1.15f)*w; val size=(h*.42f/dist).coerceAtMost(h*.8f); val left=(sx-size*.28f).toInt().coerceIn(0,rays-1)
                if(dist<zbuf[left]+.4f) { p.color=if(e.hp==1) Color.rgb(255,95,35) else Color.rgb(150,30,25); c.drawOval(RectF(sx-size*.28f,h*.48f-size*.65f,sx+size*.28f,h*.48f+size*.18f),p); p.color=Color.rgb(255,180,65); c.drawCircle(sx,h*.48f-size*.35f,size*.07f,p) }
            }
        }
        // weapon viewmodel
        p.color=Color.rgb(35,37,42); c.drawRoundRect(RectF(w*.42f,h*.77f,w*.58f,h*1.04f),14f,14f,p)
        p.color=Color.rgb(115,80,58); c.drawRect(w*.465f,h*.69f,w*.535f,h*.86f,p)
        p.color=Color.rgb(255,120,25); if(shotFlash>0f) c.drawCircle(w*.5f,h*.67f,18f*shotFlash,p)
        // HUD
        p.color=Color.argb(235,8,7,9); c.drawRect(0f,h*.9f,w,h,p)
        p.color=Color.rgb(230,95,40); p.textSize=h*.045f; p.typeface=android.graphics.Typeface.MONOSPACE
        c.drawText("HP $hp",w*.04f,h*.965f,p); c.drawText("AMMO $ammo",w*.32f,h*.965f,p); c.drawText("KILLS $kills",w*.68f,h*.965f,p)
        p.color=Color.WHITE; p.strokeWidth=2f; c.drawLine(w*.49f,h*.48f,w*.51f,h*.48f,p); c.drawLine(w*.5f,h*.465f,w*.5f,h*.495f,p)
        if(hp<=0) { p.color=Color.argb(210,0,0,0); c.drawRect(0f,0f,w,h,p); p.color=Color.RED; p.textSize=h*.09f; c.drawText("YOU DIED  •  TAP TO RESTART",w*.18f,h*.52f,p) }
        if(hurtFlash>0f) { p.color=Color.argb((hurtFlash*75).toInt(),255,0,0); c.drawRect(0f,0f,w,h,p) }
        drawControls(c,w,h)
    }
    private fun drawControls(c:Canvas,w:Float,h:Float) {
        p.color=Color.argb(55,255,255,255); c.drawCircle(w*.12f,h*.72f, h*.13f,p); c.drawCircle(w*.88f,h*.72f,h*.13f,p)
        p.color=Color.argb(140,255,255,255); p.textSize=h*.035f; c.drawText("MOVE / TURN",w*.055f,h*.73f,p); c.drawText("FIRE",w*.855f,h*.73f,p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if(hp<=0 && e.action==MotionEvent.ACTION_DOWN) { hp=100; ammo=40; kills=0; px=2.5f; py=2.5f; enemies.clear(); enemies.addAll(listOf(Enemy(8.5f,2.5f),Enemy(12.5f,7.5f),Enemy(5.5f,9.5f),Enemy(13.2f,4.5f))); return true }
        val idx=e.actionIndex; val x=e.getX(idx); val y=e.getY(idx); val w=width.toFloat()
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { if(x>w*.72f) firing=true else { if(x<w*.35f) move=1f else turn=if(x>w*.5f) 1f else -1f } }
            MotionEvent.ACTION_MOVE -> { var leftX=0f; var rightX=0f; for(i in 0 until e.pointerCount) { val tx=e.getX(i); if(tx<w*.36f) leftX=tx else if(tx<w*.72f) rightX=tx }; move=if(leftX>0) 1f else 0f; turn=if(rightX>0) if(rightX>w*.58f) 1f else -1f else 0f; firing=(0 until e.pointerCount).any { e.getX(it)>w*.72f } }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> { if(e.pointerCount<=1) { move=0f; turn=0f; firing=false } }
        }; return true
    }
}
