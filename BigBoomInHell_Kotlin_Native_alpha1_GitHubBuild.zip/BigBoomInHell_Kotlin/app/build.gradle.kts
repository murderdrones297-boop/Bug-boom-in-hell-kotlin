plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bigboominhell.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.bigboominhell.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.9.0-native-alpha1"
    }
}
